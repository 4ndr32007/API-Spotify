import React from 'react'
import "./Errore.css"

const Errore = () => {
	return (
		<div id="txt">
			<h3>Pagina non trovata, assicurati di aver inserito un URL corretto</h3>
		</div>
	)
}

export default Errore