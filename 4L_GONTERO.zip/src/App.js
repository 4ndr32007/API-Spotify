import React, { useEffect,createContext,useState } from 'react'
import {BrowserRouter,Routes,Route} from "react-router-dom"
import Home from "./Home"
import Prenotazione from "./Prenotazione"
export const parametri=createContext()
const App = () => {
  const [film, setFilm] = useState([])

 
  useEffect(() => {
    fetch("https://raw.githubusercontent.com/andgio1976/cinetown/refs/heads/main/film.json")
    .then((testo)=>testo.json())
    .then((mioJson)=>{
      console.log("mioJson")
      setFilm(mioJson)
    })
  }, [])
  
  return (
    <parametri.Provider value={
      {
      elencoFilm:film,
      modificaFilm:setFilm}
      }>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route  path='/prenotazione' element={<Prenotazione/>}/>
        </Routes>
      </BrowserRouter>
    </parametri.Provider>

  )
}

export default App