import React,{useContext} from 'react'
import {parametri} from "./App"
import {useNavigate} from "react-router-dom"
import "./Home.css"


const Home = () => {
    const prova =useContext(parametri)
    const link=useNavigate()
    const apri=(cine)=>{
        link("/prenotazione",{state:{"nomeCine":cine}})
    }
    const visualizza=()=>{
        return prova.elencoFilm.map((elemento)=>{
            return (
                <div >
                    <div className='container'>
                        <span><img width={"350vh"} src={elemento.foto}/></span>
                        <span>
                            <div id='divvone'>
                                <div><input type="button" value={"Vail alla pagina di prenotazione"} onClick={()=>apri(elemento.nome)}/></div>
                            </div>
                        </span>
                    </div>
                </div>
            )
        })
    }
  return (
    <div>
        {visualizza()}
    </div>
  )
}

export default Home
