import React,{useContext} from 'react'
import {useLocation} from "react-router-dom"
import {parametri} from "./App"
import "./Prenotazione.css"
let nPosti=0
const Prenotazione = () => {
  const {state}=useLocation()
  const mioArray= useContext(parametri)

  
  const addPost=()=>{

    nPosti++

  }

  const totale=()=>{

    let tot=nPosti*12

    alert("il totale è totale è "+tot)

  }


  const visualizza=()=>{
    
        return(
            <div id='griglia'>
              <div>
                <h2>prenota i posti</h2>
                  <div>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                  </div>
                  <div>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                  </div>
                  <div>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                    <input type='button' value={"prenota posto"} onClick={addPost}/>
                  </div>
                  <input type='button' value={"costo biglietti"} onClick={totale}/>
              </div>
            </div>

        )

    
  }
    return (
    <div>{visualizza()}</div>
  )
}

export default Prenotazione